The Logging Plugin
==================
