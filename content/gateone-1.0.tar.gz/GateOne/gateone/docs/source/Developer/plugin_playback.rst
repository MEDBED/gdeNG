The Playback Plugin
===================
