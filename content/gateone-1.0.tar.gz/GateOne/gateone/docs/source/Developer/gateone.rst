:mod:`gateone.py` - Gate One's Main Script
==========================================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: gateone
    :members:
    :private-members:
