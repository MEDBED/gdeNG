:mod:`utils.py` - Supporting Functions
======================================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: utils
    :members:
    :private-members:
