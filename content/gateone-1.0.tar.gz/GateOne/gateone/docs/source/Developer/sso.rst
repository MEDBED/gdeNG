:mod:`sso.py` - A Tornado Kerberos Single Sign-On Module
========================================================

.. moduleauthor:: Dan McDougall <daniel.mcdougall@liftoffsoftware.com>

.. automodule:: sso
    :members:
    :private-members:
